#Librerias
from gpiozero import DistanceSensor, Device
from gpiozero.pins.pigpio import PiGPIOFactory
import csv
import os
import logging
import time
import board
import adafruit_dht

#Configuración logging
log_file = "/home/raspi/Desktop/mp2/log.csv"
if not os.path.isfile(log_file):
    with open(log_file, mode = "w", newline = "") as f:
        writer = csv.writer(f)
        writer.writerow(["timestamp", "temperature_c", "humidity", "distance_cm"])

Device.pin_factory = PiGPIOFactory()
dhtDevice = adafruit_dht.DHT11(board.D4)
sensor = DistanceSensor(echo = 24, trigger = 23, max_distance = 3)

try:
    while True:
        try:
            distance = sensor.distance * 100
            if distance < 2 or distance > 300:
                print("ERROR, NO SE PUEDE MEDIR DISTANCIA: SENSOR FUERA DE RANGO")
                print("---------------------------------------------------------")
            else:
                print(f"Distancia Medida: {distance:.2f} cm")
            temperature_c = dhtDevice.temperature
            humidity = dhtDevice.humidity
            print("Temperatura Registrada: {:.1f}°C | Humedad Registrada:{}%".format(temperature_c, humidity))
            with open(log_file, mode = "a", newline = "") as f:
                writer = csv.writer(f)
                writer.writerow([time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()), temperature_c, humidity, distance])
        except OSError as error:
            print(error.args[0])
        except RuntimeError as error:
            print(error.args[0])
            time.sleep(2)
        except Exception as error:
            raise error

        time.sleep(2.0)
finally:
    if dhtDevice:
        dhtDevice.exit()